# Cube

This model was contributed by Kevin Zakka. For details regarding its creation, see the associated [repository](https://github.com/kevinzakka/mujoco_cube).

Click the video below to see a user interacting with the cube:

[![3x3x3 cube example model](https://img.youtube.com/vi/ZppeDArq6AU/0.jpg)](https://www.youtube.com/watch?v=ZppeDArq6AU)
